filename P2ED0E87 list;
%put NOTE: Unloading package SASDoGs, version 0.2, license MIT;
%put NOTE- *** START ***;
proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'SASDOGSMETA'
   ,'SASDOGSIML'
   ,'SASDOGSCASLUDF'
   %put NOTE- Element of type macro generated from the file "_indexmd.sas" will be deleted;
   %put NOTE- ;
   ,"_INDEXMD                                                        "
   %put NOTE- Element of type macro generated from the file "_inner.sas" will be deleted;
   %put NOTE- ;
   ,"_INNER                                                          "
   %put NOTE- Element of type macro generated from the file "_mystdoc.sas" will be deleted;
   %put NOTE- ;
   ,"_MYSTDOC                                                        "
   %put NOTE- Element of type macro generated from the file "_spfdoc.sas" will be deleted;
   %put NOTE- ;
   ,"_SPFDOC                                                         "
   %put NOTE- Element of type macro generated from the file "_sphinxdoc.sas" will be deleted;
   %put NOTE- ;
   ,"_SPHINXDOC                                                      "
   %put NOTE- Element of type macro generated from the file "collectfiles.sas" will be deleted;
   %put NOTE- ;
   ,"COLLECTFILES                                                    "
   %put NOTE- Element of type macro generated from the file "generatemd.sas" will be deleted;
   %put NOTE- ;
   ,"GENERATEMD                                                      "
   %put NOTE- Element of type macro generated from the file "packagedoc.sas" will be deleted;
   %put NOTE- ;
   ,"PACKAGEDOC                                                      "
  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"
  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'SASDOGSFORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc fcmp outlib = work.SASDoGsfcmp.package;
quit;

proc fcmp outlib = work.SASDoGsfcmp.packagemeta;
deletefunc SASDoGsMETA;
quit;

options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.sasdogsfcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%put; %put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));
proc SQL noprint;
quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

run;

data _null_ ;                                                                                         
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#sasdogs(0.2)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#SASDoGs(0.2)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  
%put NOTE: Unloading package SASDoGs, version 0.2, license MIT;
%put NOTE- *** END ***;
%put NOTE- ;
/* unload.sas end */
